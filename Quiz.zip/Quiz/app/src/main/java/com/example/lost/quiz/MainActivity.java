package com.example.lost.quiz;

import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import static android.R.attr.button;

public class MainActivity extends AppCompatActivity {
    MediaPlayer mysong;
    int grade;
    int totalGrade;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mysong = MediaPlayer.create(MainActivity.this, R.raw.song);

    }

    public void play(View v) {
        mysong.start();

    }

    public void pause(View v) {
        mysong.pause();
    }


    public void submit(View view) {
        String gender;
        EditText name = (EditText) findViewById(R.id.nameText);
        String textName = name.getText().toString();
        RadioButton maleGender = (RadioButton) findViewById(R.id.maleRadioButton);
        boolean checkMale = maleGender.isChecked();
        if (checkMale) {
            gender = "male";
        } else gender = "female";

        RadioButton femaleGender = (RadioButton) findViewById(R.id.femaleRadioButton);
        boolean checkFemale = femaleGender.isChecked();
        RadioButton solutionOfQuestionOne = (RadioButton) findViewById(R.id.choice_a_question_one);
        boolean checkQuestionOne = solutionOfQuestionOne.isChecked();
        RadioButton solutionOfQuestionTwo = (RadioButton) findViewById(R.id.choice_b_question_two);
        boolean checkQuestionTwo = solutionOfQuestionTwo.isChecked();
        RadioButton solutionOfQuestionThree = (RadioButton) findViewById(R.id.choice_b_question_three);
        boolean checkQuestionThree = solutionOfQuestionThree.isChecked();
        CheckBox solutionOfQuestionFour1 = (CheckBox) findViewById(R.id.choice_a_question_four);
        boolean checkQuestionFour1 = solutionOfQuestionFour1.isChecked();
        CheckBox solutionOfQuestionFour2 = (CheckBox) findViewById(R.id.choice_c_question_four);
        boolean checkQuestionFour2 = solutionOfQuestionFour2.isChecked();
        CheckBox solutionOfQuestionFour3 = (CheckBox) findViewById(R.id.choice_b_question_four);
        boolean checkQuestionFour3 = solutionOfQuestionFour3.isChecked();
        CheckBox solutionOfQuestionFour4 = (CheckBox) findViewById(R.id.choice_d_question_four);
        boolean checkQuestionFour4 = solutionOfQuestionFour4.isChecked();
        EditText solutionOfQuestionFive = (EditText) findViewById(R.id.text_question_five);
        String checkQuestionFive = solutionOfQuestionFive.getText().toString().toLowerCase();

        if (checkQuestionOne) {
            totalGrade = totalGrade + 20;
        }

        if (checkQuestionTwo) {
            totalGrade = totalGrade + 20;
        }
        if (checkQuestionThree) {
            totalGrade = totalGrade + 20;
        }
        if (checkQuestionFour1 && checkQuestionFour2 && !checkQuestionFour3 && !checkQuestionFour4) {
            totalGrade = totalGrade + 20;
        }
        if (checkQuestionFive.equalsIgnoreCase("shahrzad")) {
            totalGrade = totalGrade + 20;
        }
        Toast.makeText(this, "Name: " + textName + "\n" + "gender: " + gender + "\n" + "grade: " + totalGrade + "/80", Toast.LENGTH_LONG).show();
        totalGrade = totalGrade * 0;

    }

}
